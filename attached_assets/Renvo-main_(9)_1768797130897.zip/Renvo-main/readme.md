# HomeComps

A real estate comparables platform.

## Project Structure

- **public/**  
  Contains static files (HTML, CSS, JS, images).  
- **src/**  
  Contains server-side code, such as an Express app.

## Getting Started

1. **Install** dependencies:
   ```bash
   npm install
# Test for staging environment123456